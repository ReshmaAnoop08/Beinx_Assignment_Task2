
from django import forms
from django.forms import fields
from .models import  Products, Category, SubCategory


class CreateCategoryForm(forms.ModelForm):
    name = forms.CharField(required=True)
    
    class Meta:
        model = Category
        fields = '__all__'


class CreateSubCategoryForm(forms.ModelForm):
    name = forms.CharField(required=True)
    categories = forms.ModelChoiceField(
        queryset = Category.objects.all(),
        initial = 0,
        widget=forms.Select(attrs={"onChange":'refresh()'})
        )
    class Meta:
        model = SubCategory
        fields = ("name", "categories")


class CreateProductForm(forms.ModelForm):
    name = forms.CharField(required=True)
    price = forms.CharField(required=True)
    description = forms.Textarea()
    category = forms.ModelChoiceField(
        queryset = SubCategory.objects.all(),
        initial = 0,
        widget=forms.Select(attrs={"onChange":'refresh()'})
        )
    class Meta:
        model = Products
        fields = '__all__'
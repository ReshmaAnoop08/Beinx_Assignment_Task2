from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout 
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.views.generic.edit import CreateView
from adminapp.models import  Products, SubCategory
from adminapp.forms import CreateCategoryForm, CreateSubCategoryForm, CreateProductForm
# Create your views here.

def login_request(request):
    """
    function for login.
    """
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                return render(request=request, template_name="home.html")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="login.html", context={"login_form":form})

def logout_request(request):
    """
    function for logout.
    """
    logout(request)
    messages.info(request, "You have successfully logged out.") 
    return redirect("login")

class CreateCategory(CreateView):
    """
    created category.
    """
    def get(self, request):
        form = CreateCategoryForm()
        return render(request, "addcategory.html", {'form' : form})
    def post(self, request):
        msg = None
        form = CreateCategoryForm(request.POST)
        if form.is_valid():
            form = form.save(commit = False)
            form.save()
            msg = 'Category added successfully'
        form = CreateCategoryForm()
        return render(request,"addcategory.html", {'form' : form, 'msg' : msg})

class CreateSubCategory(CreateView):
    """
    created subcategory.
    """
    def get(self, request):
        form = CreateSubCategoryForm()
        return render(request, "addsubcategory.html", {'form' : form})
    def post(self, request):
        msg = None
        fm = CreateSubCategoryForm(request.POST)
        if fm.is_valid():
            sub_obj = SubCategory.objects.create(name =fm.cleaned_data['name'] )
            sub_obj.categories.add(fm.cleaned_data['categories'])
            form = sub_obj.save()
            msg = 'Subcategory  added successfully'
        form = CreateSubCategoryForm()
        return render(request,"addsubcategory.html", {'form' : form, 'msg' : msg})

class CreateProduct(CreateView):
    """
    created product.
    """
    def get(self, request):
        form = CreateProductForm()
        return render(request, "addproduct.html", {'form' : form})
    def post(self, request):
        msg = None
        fm = CreateProductForm(request.POST)
        if fm.is_valid():
            product_obj = Products.objects.create(name = fm.cleaned_data['name'],price= fm.cleaned_data['price'],
                    description=fm.cleaned_data['description'])
            product_obj.category.add(fm.cleaned_data['category'])
            form = product_obj.save()
            msg = 'Product  added successfully'
        form = CreateProductForm()
        return render(request,"addproduct.html", {'form' : form, 'msg' : msg})


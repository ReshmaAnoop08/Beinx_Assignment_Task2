from django.db import models

class Category(models.Model):
    name= models.CharField(max_length=50)

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

    def __str__(self):
        return self.name

class SubCategory(models.Model):
    name = models.TextField(max_length=50)
    categories = models.ManyToManyField(Category)

    def __str__(self):
        return self.name

class Products(models.Model):
    name = models.CharField(max_length=60,blank=True, null=True)
    price = models.IntegerField(default=0,blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    category= models.ManyToManyField(SubCategory)

    def __str__(self):
        return self.name
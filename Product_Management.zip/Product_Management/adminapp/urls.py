from django.urls import path
from .views import (
  CreateCategory, CreateSubCategory, CreateProduct
    )

urlpatterns = [
    path('create-category/', CreateCategory.as_view(),name='create-category'),
    path('create-subcategory/', CreateSubCategory.as_view(),name='create-subcategory'),
    path('create-product/', CreateProduct.as_view(),name='create-product'),
]
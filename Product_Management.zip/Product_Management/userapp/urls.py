from django.urls import path
from .views import (
  ListProducts, SearchProducts
    )

urlpatterns = [
    path('list-products/', ListProducts.as_view(),name='list-products'),
    path('search-products/', SearchProducts.as_view(),name='search-products'),
  

]
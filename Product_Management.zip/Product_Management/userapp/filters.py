import django_filters
from adminapp.models import Products, Category, SubCategory

class ProductFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='iexact')

    class Meta:
        model = Products
        fields = '__all__'

class CategoryFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='iexact')

    class Meta:
        model = Category
        fields = '__all__'

class SubCategoryFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='iexact')

    class Meta:
        model = SubCategory
        fields = '__all__'
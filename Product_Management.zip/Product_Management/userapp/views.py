from django.shortcuts import render
from django.views.generic.list import ListView
from adminapp.models import Products, Category, SubCategory
from userapp.filters import ProductFilter,CategoryFilter, SubCategoryFilter
# Create your views here.

class ListProducts(ListView):
    """
    List all the products.
    """
    def get(self, request):
        products = Products.objects.all()
        return render(request, "listproducts.html", {'products' : products})

class SearchProducts(ListView):
    """
    search products by the user functionality.
    """
    def get(self, request):
        products = Products.objects.all()
        fp = ProductFilter(request.GET, queryset=Products.objects.all())
        fc = CategoryFilter(request.GET, queryset=Category.objects.all())
        fs = SubCategoryFilter(request.GET, queryset=SubCategory.objects.all())
        return render(request, "searchproducts.html", {'pfilter': fp,'cfilter': fc,'sfilter': fs,
                                                        'products': products})